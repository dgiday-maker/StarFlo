import React from 'react';

export const Logo = ({ className = "w-10 h-10", src }: { className?: string, src?: string }) => {
  if (src) {
    return (
      <div className={`relative ${className} flex items-center justify-center bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100`}>
        <img src={src} alt="Logo" className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" />
      </div>
    );
  }
  return (
    <div className={`relative ${className} flex items-center justify-center bg-netsuite-blue rounded-lg shadow-sm`}>
      <span className="text-white font-sans font-bold text-lg tracking-tighter">SN</span>
    </div>
  );
};
