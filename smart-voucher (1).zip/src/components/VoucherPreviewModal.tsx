import React from 'react';
import { Voucher, UserRole, PrintSettings } from '../types';
import { X, CheckCircle2, ShieldCheck, FileText, Download, Paperclip, Clock, XCircle, Printer } from 'lucide-react';
import { format } from 'date-fns';
import { formatCurrency } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { Logo } from './Logo';

interface VoucherPreviewModalProps {
  voucher: Voucher;
  onClose: () => void;
  onPrint: (voucher: Voucher) => void;
  onFullPrint: (voucher: Voucher) => void;
  userRole: UserRole;
  settings: PrintSettings;
}

export default function VoucherPreviewModal({ 
  voucher, 
  onClose, 
  onPrint,
  onFullPrint,
  userRole,
  settings
}: VoucherPreviewModalProps) {
  const canVerify = (userRole === 'verifier' || userRole === 'admin') && voucher.status === 'prepared';
  const canApprove = (userRole === 'approver' || userRole === 'admin') && voucher.status === 'verified';

  const totalDebit = voucher.entries?.reduce((sum, entry) => sum + (Number(entry.debit) || 0), 0) || 0;
  const totalCredit = voucher.entries?.reduce((sum, entry) => sum + (Number(entry.credit) || 0), 0) || 0;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-5xl max-h-[90vh] rounded-lg shadow-2xl overflow-hidden flex flex-col"
      >
        {/* Modal Header */}
        <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div className="flex items-center gap-4">
            {settings.companyLogo ? (
              <img src={settings.companyLogo} alt="Logo" className="w-12 h-12 object-contain" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-12 h-12 bg-netsuite-blue/10 rounded flex items-center justify-center text-netsuite-blue">
                <Logo className="w-8 h-8" />
              </div>
            )}
            <div>
              <h2 className="text-xl font-sans font-bold text-gray-900">{settings.companyName || settings.organizationName}</h2>
              <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">Voucher ID: {voucher.id.toUpperCase()}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-200 rounded-full transition-colors text-gray-400 hover:text-gray-900"
          >
            <X size={24} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-8 space-y-10">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-1">
              <p className="text-[10px] uppercase font-sans font-bold text-gray-400 tracking-wider">Date</p>
              <p className="text-sm font-sans font-bold text-gray-900">{format(new Date(voucher.date), 'dd MMMM yyyy')}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase font-sans font-bold text-gray-400 tracking-wider">Check Number</p>
              <p className="text-sm font-sans font-bold text-netsuite-blue">{voucher.checkNumber || 'N/A'}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase font-sans font-bold text-gray-400 tracking-wider">Payee</p>
              <p className="text-sm font-sans font-bold text-gray-900">{voucher.payee}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase font-sans font-bold text-gray-400 tracking-wider">Status</p>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-sans font-bold uppercase border flex items-center gap-1 w-fit ${
                  voucher.status === 'approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                  voucher.status === 'verified' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                  voucher.status === 'prepared' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                  'bg-gray-100 text-gray-600 border-gray-200'
                }`}>
                  {voucher.status === 'approved' && <ShieldCheck size={12} />}
                  {voucher.status === 'verified' && <CheckCircle2 size={12} />}
                  {voucher.status === 'prepared' && <Clock size={12} />}
                  {voucher.status === 'draft' && <FileText size={12} />}
                  {voucher.status === 'void' && <XCircle size={12} />}
                  {voucher.status}
                </span>
              </div>
            </div>
          </div>

          {/* Details & Amount */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-1">
              <p className="text-[10px] uppercase font-sans font-bold text-gray-400 tracking-wider">Purpose / Details</p>
              <p className="text-sm font-sans text-gray-700 leading-relaxed bg-gray-50 p-4 rounded border border-gray-100">
                {voucher.accountDetails}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase font-sans font-bold text-gray-400 tracking-wider">Total Amount (Local)</p>
              <div className="text-2xl font-sans font-bold text-netsuite-blue bg-netsuite-blue/5 p-4 rounded border border-netsuite-blue/10">
                {formatCurrency(voucher.amount)}
              </div>
              {voucher.exchangeRate && (
                <div className="mt-2 p-2 bg-gray-50 rounded border border-gray-100">
                  <p className="text-[8px] uppercase font-sans font-bold text-gray-400 tracking-wider mb-1">USD Equivalent</p>
                  <p className="text-sm font-sans font-bold text-gray-700">
                    $ {(voucher.amount / voucher.exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-[8px] text-gray-400 font-sans italic">Rate: 1 USD = {voucher.exchangeRate}</p>
                </div>
              )}
            </div>
          </div>

          {/* Accounting Table */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">Accounting Distribution</h3>
            <div className="border border-gray-100 rounded overflow-hidden shadow-sm">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-50 text-[10px] uppercase font-sans font-bold text-gray-500 border-b border-gray-100">
                    <th className="p-4 text-left">Account Code</th>
                    <th className="p-4 text-left">Description</th>
                    <th className="p-4 text-right w-24">Debit</th>
                    <th className="p-4 text-right w-24">Credit</th>
                    {voucher.exchangeRate && (
                      <>
                        <th className="p-4 text-right w-24">Debit (USD)</th>
                        <th className="p-4 text-right w-24">Credit (USD)</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody className="text-sm font-sans">
                  {voucher.entries?.map((entry, i) => (
                    <tr key={i} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/30 transition-colors">
                      <td className="p-4">
                        <span className="px-3 py-1 bg-netsuite-blue/10 text-netsuite-blue font-bold rounded text-xs border border-netsuite-blue/20">
                          {entry.accountCode || 'N/A'}
                        </span>
                      </td>
                      <td className="p-4 text-gray-900">{entry.description}</td>
                      <td className="p-4 text-right text-gray-900">{entry.debit > 0 ? entry.debit.toFixed(2) : '-'}</td>
                      <td className="p-4 text-right text-gray-900">{entry.credit > 0 ? entry.credit.toFixed(2) : '-'}</td>
                      {voucher.exchangeRate && (
                        <>
                          <td className="p-4 text-right text-gray-400 italic">{entry.debitUSD ? entry.debitUSD.toFixed(2) : '-'}</td>
                          <td className="p-4 text-right text-gray-400 italic">{entry.creditUSD ? entry.creditUSD.toFixed(2) : '-'}</td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50/50 font-bold border-t border-gray-100">
                  <tr className="text-sm font-sans">
                    <td colSpan={2} className="p-4 text-right uppercase text-[10px] text-gray-400 tracking-widest">Totals</td>
                    <td className="p-4 text-right text-netsuite-blue">{totalDebit.toFixed(2)}</td>
                    <td className="p-4 text-right text-netsuite-blue">{totalCredit.toFixed(2)}</td>
                    {voucher.exchangeRate && (
                      <>
                        <td className="p-4 text-right text-gray-400">{(totalDebit / voucher.exchangeRate).toFixed(2)}</td>
                        <td className="p-4 text-right text-gray-400">{(totalCredit / voucher.exchangeRate).toFixed(2)}</td>
                      </>
                    )}
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Source Documents / Attachments */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Paperclip size={16} className="text-netsuite-blue" />
              <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">Source Documents / Attachments</h3>
            </div>
            {voucher.attachments && voucher.attachments.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {voucher.attachments.map((file, index) => (
                  <div key={index} className="group relative bg-white border border-gray-200 rounded overflow-hidden shadow-sm hover:shadow-md transition-all">
                    {file.startsWith('data:image/') ? (
                      <div className="aspect-video relative overflow-hidden bg-gray-100">
                        <img src={file} alt={`Attachment ${index + 1}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                          <a 
                            href={file} 
                            download={`attachment-${index + 1}.png`}
                            className="p-2 bg-white rounded-full text-netsuite-blue hover:scale-110 transition-transform"
                            title="Download"
                          >
                            <Download size={20} />
                          </a>
                        </div>
                      </div>
                    ) : (
                      <div className="aspect-video flex flex-col items-center justify-center bg-gray-50 text-gray-400 gap-2">
                        <FileText size={40} />
                        <span className="text-[10px] font-sans uppercase">Document {index + 1}</span>
                      </div>
                    )}
                    <div className="p-3 bg-white border-t border-gray-100 flex items-center justify-between">
                      <span className="text-[10px] font-sans text-gray-500 uppercase">Attachment {index + 1}</span>
                      <a href={file} target="_blank" rel="noreferrer" className="text-[10px] font-sans text-netsuite-blue hover:underline">View Full</a>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 border-2 border-dashed border-gray-100 rounded text-center">
                <p className="text-sm text-gray-400 italic">No source documents attached to this voucher.</p>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer / Actions */}
        <div className="p-6 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between">
          <div className="flex items-center gap-6 overflow-x-auto pb-2">
            <div className="text-left shrink-0">
              <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">Prepared By</p>
              <p className="text-xs font-sans text-gray-900 font-bold">{voucher.preparedBy || settings.defaultPreparedBy}</p>
            </div>
            {settings.defaultAuthorizedBy1 && (
              <>
                <div className="h-8 w-px bg-gray-200 shrink-0" />
                <div className="text-left shrink-0">
                  <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">Auth 1</p>
                  <p className="text-xs font-sans text-gray-900 font-bold">{settings.defaultAuthorizedBy1}</p>
                </div>
              </>
            )}
            {settings.defaultAuthorizedBy2 && (
              <>
                <div className="h-8 w-px bg-gray-200 shrink-0" />
                <div className="text-left shrink-0">
                  <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">Auth 2</p>
                  <p className="text-xs font-sans text-gray-900 font-bold">{settings.defaultAuthorizedBy2}</p>
                </div>
              </>
            )}
            {settings.defaultAuthorizedBy3 && (
              <>
                <div className="h-8 w-px bg-gray-200 shrink-0" />
                <div className="text-left shrink-0">
                  <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">Auth 3</p>
                  <p className="text-xs font-sans text-gray-900 font-bold">{settings.defaultAuthorizedBy3}</p>
                </div>
              </>
            )}
            {(voucher.receivedBy || settings.defaultReceivedBy) && (
              <>
                <div className="h-8 w-px bg-gray-200 shrink-0" />
                <div className="text-left shrink-0">
                  <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">Received By</p>
                  <p className="text-xs font-sans text-gray-900 font-bold">{voucher.receivedBy || settings.defaultReceivedBy}</p>
                </div>
              </>
            )}
          </div>

          <div className="flex gap-4">
            <button 
              onClick={onClose}
              className="px-6 py-2 rounded font-sans text-sm text-gray-500 hover:bg-gray-200 transition-colors"
            >
              Close
            </button>
            
            <button 
              onClick={() => onPrint(voucher)}
              className="flex items-center gap-2 bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-50 transition-colors font-sans text-sm shadow-sm"
            >
              <Printer size={16} />
              Print Voucher
            </button>
            <button 
              onClick={() => onFullPrint(voucher)}
              className="flex items-center gap-2 bg-netsuite-blue text-white px-8 py-2 rounded hover:bg-netsuite-blue-dark transition-colors font-sans text-sm shadow-lg shadow-netsuite-blue/20"
            >
              <FileText size={18} />
              Print Full Voucher
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
