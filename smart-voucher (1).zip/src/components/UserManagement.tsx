import React, { useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, onSnapshot, doc, updateDoc, setDoc, query, orderBy } from 'firebase/firestore';
import { UserPlus, Shield, CheckCircle, XCircle, Mail, User as UserIcon, Loader2, Search, Edit2, Save, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function UserManagement() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [inviting, setInviting] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState<UserRole>('preparer');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('preparer');

  useEffect(() => {
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const usersData = snapshot.docs.map(doc => ({
        ...doc.data(),
        uid: doc.id
      })) as UserProfile[];
      setUsers(usersData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail || !inviteName) return;

    setInviting(true);
    try {
      const newUserId = `pending_${Date.now()}`;
      await setDoc(doc(db, 'users', newUserId), {
        uid: newUserId,
        email: inviteEmail.toLowerCase(),
        displayName: inviteName,
        role: inviteRole,
        active: false,
        createdAt: new Date().toISOString()
      });
      
      setInviteEmail('');
      setInviteName('');
      setInviteRole('preparer');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'users');
    } finally {
      setInviting(false);
    }
  };

  const toggleUserStatus = async (user: UserProfile) => {
    const action = user.active ? 'deactivate' : 'activate';
    if (!window.confirm(`Are you sure you want to ${action} ${user.displayName}?`)) return;

    try {
      await updateDoc(doc(db, 'users', user.uid), {
        active: !user.active
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const startEditing = (user: UserProfile) => {
    setEditingId(user.uid);
    setEditName(user.displayName);
    setEditEmail(user.email);
    setEditRole(user.role);
  };

  const cancelEditing = () => {
    setEditingId(null);
  };

  const saveEdit = async (uid: string) => {
    try {
      await updateDoc(doc(db, 'users', uid), {
        displayName: editName,
        email: editEmail.toLowerCase(),
        role: editRole
      });
      setEditingId(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
    }
  };

  const filteredUsers = users.filter(u => 
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="animate-spin text-netsuite-blue" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-sans font-bold text-netsuite-blue">User Management</h2>
          <p className="text-gray-500 text-[10px] font-sans uppercase tracking-widest mt-1">Manage system access, roles, and invitations.</p>
        </div>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 bg-white border border-gray-200 rounded text-sm w-full focus:outline-none focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-sans"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="bg-white border border-gray-200 rounded p-6 shadow-sm sticky top-24">
            <div className="flex items-center gap-2 mb-6">
              <div className="p-2 bg-netsuite-blue/10 rounded text-netsuite-blue">
                <UserPlus size={20} />
              </div>
              <h3 className="font-bold text-gray-900 font-sans">Invite New User</h3>
            </div>

            <form onSubmit={handleInvite} className="space-y-4">
              <div>
                <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-1.5">Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <input
                    type="text"
                    required
                    value={inviteName}
                    onChange={(e) => setInviteName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <input
                    type="email"
                    required
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    placeholder="john@example.com"
                    className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-1.5">Initial Role</label>
                <div className="relative">
                  <Shield className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value as UserRole)}
                    className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-sans appearance-none"
                  >
                    <option value="preparer">Preparer</option>
                    <option value="verifier">Verifier</option>
                    <option value="approver">Approver</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={inviting}
                className="w-full py-2 bg-netsuite-blue text-white rounded font-bold text-sm hover:bg-netsuite-blue-dark transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-sm"
              >
                {inviting ? <Loader2 className="animate-spin" size={18} /> : <UserPlus size={18} />}
                Send Invitation
              </button>
            </form>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white border border-gray-200 rounded overflow-hidden shadow-sm">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">User</th>
                  <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">Role</th>
                  <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">Status</th>
                  <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {filteredUsers.map((user, index) => (
                  <tr 
                    key={user.uid} 
                    className={cn(
                      "border-t border-gray-100 transition-colors",
                      index % 2 === 1 ? "bg-gray-50/[0.3]" : "bg-white"
                    )}
                  >
                    <td className="p-4">
                      {editingId === user.uid ? (
                        <div className="space-y-2">
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full px-2 py-1 border rounded text-xs font-sans"
                          />
                          <input
                            type="email"
                            value={editEmail}
                            onChange={(e) => setEditEmail(e.target.value)}
                            className="w-full px-2 py-1 border rounded text-xs font-sans"
                          />
                        </div>
                      ) : (
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-netsuite-blue/10 flex items-center justify-center text-netsuite-blue font-bold text-xs">
                            {user.displayName.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-gray-900">{user.displayName}</div>
                            <div className="text-xs text-gray-500 font-sans">{user.email}</div>
                          </div>
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      {editingId === user.uid ? (
                        <select
                          value={editRole}
                          onChange={(e) => setEditRole(e.target.value as UserRole)}
                          className="w-full px-2 py-1 border rounded text-xs font-sans"
                        >
                          <option value="preparer">Preparer</option>
                          <option value="verifier">Verifier</option>
                          <option value="approver">Approver</option>
                          <option value="admin">Admin</option>
                        </select>
                      ) : (
                        <span className="font-medium text-gray-600 font-sans capitalize">{user.role}</span>
                      )}
                    </td>
                    <td className="p-4">
                      <span className={cn(
                        "px-2 py-0.5 rounded-full text-[9px] font-bold uppercase border flex items-center gap-1 w-fit",
                        user.active 
                          ? "bg-emerald-50 text-emerald-600 border-emerald-100" 
                          : "bg-red-50 text-red-600 border-red-100"
                      )}>
                        {user.active ? <CheckCircle size={10} /> : <XCircle size={10} />}
                        {user.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {editingId === user.uid ? (
                          <>
                            <button
                              onClick={() => saveEdit(user.uid)}
                              className="p-2 text-emerald-500 hover:bg-emerald-50 rounded transition-all"
                              title="Save Changes"
                            >
                              <Save size={18} />
                            </button>
                            <button
                              onClick={cancelEditing}
                              className="p-2 text-gray-400 hover:bg-gray-100 rounded transition-all"
                              title="Cancel"
                            >
                              <X size={18} />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => startEditing(user)}
                              className="p-2 text-gray-400 hover:text-netsuite-blue hover:bg-netsuite-blue/5 rounded transition-all"
                              title="Edit User"
                            >
                              <Edit2 size={18} />
                            </button>
                            <button
                              onClick={() => toggleUserStatus(user)}
                              className={cn(
                                "p-2 rounded transition-all",
                                user.active 
                                  ? "text-red-500 hover:bg-red-50" 
                                  : "text-emerald-500 hover:bg-emerald-50"
                              )}
                              title={user.active ? "Deactivate User" : "Activate User"}
                            >
                              {user.active ? <XCircle size={18} /> : <CheckCircle size={18} />}
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
