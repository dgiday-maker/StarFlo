import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Voucher, AccountingEntry, UserProfile, Payee, Account, PrintSettings } from '../types';
import { Save, X, ArrowLeft, Plus, Trash2, Paperclip, FileImage, XCircle } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { Logo } from './Logo';

interface VoucherFormProps {
  onSave: (voucher: Omit<Voucher, 'id' | 'createdAt' | 'createdBy'>) => void;
  onCancel: () => void;
  userProfile: UserProfile | null;
  settings: PrintSettings;
}

export default function VoucherForm({ onSave, onCancel, userProfile, settings }: VoucherFormProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [payees, setPayees] = useState<Payee[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    payee: '',
    amount: '',
    checkNumber: `${settings.checkNumberPattern || ''}${String(settings.nextCheckNumber || 1).padStart(4, '0')}`,
    exchangeRate: '',
    accountDetails: '',
    preparedBy: settings.defaultPreparedBy || userProfile?.displayName || '',
    receivedBy: settings.defaultReceivedBy || '',
    voucherNumber: `${settings.voucherNumberPattern || 'CPV-2024-'}${String(settings.nextVoucherNumber || 1).padStart(4, '0')}`,
  });

  const [attachments, setAttachments] = useState<string[]>([]);
  const [entries, setEntries] = useState<AccountingEntry[]>([
    { accountCode: '', description: '', debit: 0, credit: 0 },
  ]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Fetch Payees
    const qPayees = query(collection(db, 'payees'), orderBy('name', 'asc'));
    const unsubscribePayees = onSnapshot(qPayees, (snapshot) => {
      setPayees(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }) as Payee));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'payees'));

    // Fetch Accounts
    const qAccounts = query(collection(db, 'accounts'), orderBy('code', 'asc'));
    const unsubscribeAccounts = onSnapshot(qAccounts, (snapshot) => {
      setAccounts(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }) as Account));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'accounts'));

    return () => {
      unsubscribePayees();
      unsubscribeAccounts();
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate entries
    const invalidEntries = entries.filter(entry => 
      (entry.debit > 0 || entry.credit > 0 || entry.description) && !entry.accountCode
    );

    if (invalidEntries.length > 0) {
      setError("Please select an Account Code for all entries that have a description or amount.");
      return;
    }

    onSave({
      ...formData,
      amount: parseFloat(formData.amount) || 0,
      exchangeRate: parseFloat(formData.exchangeRate) || undefined,
      entries,
      attachments,
      status: 'approved',
      preparedByUid: userProfile?.uid,
      preparedAt: new Date().toISOString(),
      preparedSignature: userProfile?.signatureUrl,
      verifiedBy: '',
      approvedBy: '',
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      (Array.from(files) as File[]).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setAttachments(prev => [...prev, reader.result as string]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => {
      const newData = { ...prev, [name]: value };
      
      // If amount changes and we only have one entry, update it
      if (name === 'amount' && entries.length === 1) {
        const amount = parseFloat(value) || 0;
        setEntries([{ ...entries[0], debit: amount }]);
      }
      
      return newData;
    });
  };

  const handleEntryChange = (index: number, updates: Partial<AccountingEntry>) => {
    setEntries(prev => {
      const newEntries = [...prev];
      const rate = parseFloat(formData.exchangeRate);
      
      const updatedEntry = { ...newEntries[index], ...updates };
      
      if (!isNaN(rate) && rate > 0) {
        if ('debit' in updates) {
          updatedEntry.debitUSD = (updates.debit || 0) / rate;
        }
        if ('credit' in updates) {
          updatedEntry.creditUSD = (updates.credit || 0) / rate;
        }
      }
      
      newEntries[index] = updatedEntry;
      return newEntries;
    });
  };

  useEffect(() => {
    const rate = parseFloat(formData.exchangeRate);
    if (!isNaN(rate) && rate > 0) {
      setEntries(prev => prev.map(entry => ({
        ...entry,
        debitUSD: (entry.debit || 0) / rate,
        creditUSD: (entry.credit || 0) / rate
      })));
    } else {
      setEntries(prev => prev.map(entry => ({
        ...entry,
        debitUSD: undefined,
        creditUSD: undefined
      })));
    }
  }, [formData.exchangeRate]);

  const addEntry = () => {
    const totalAmount = parseFloat(formData.amount) || 0;
    const currentDebitTotal = entries.reduce((sum, e) => sum + (e.debit || 0), 0);
    const balance = Math.max(0, totalAmount - currentDebitTotal);
    
    setEntries([...entries, { accountCode: '', description: '', debit: balance, credit: 0 }]);
  };

  const removeEntry = (index: number) => {
    if (entries.length <= 1) return;
    setEntries(entries.filter((_, i) => i !== index));
  };

  const totalDebit = entries.reduce((sum, entry) => sum + (Number(entry.debit) || 0), 0);
  const totalCredit = entries.reduce((sum, entry) => sum + (Number(entry.credit) || 0), 0);

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex items-center gap-4">
            {settings.companyLogo ? (
              <img src={settings.companyLogo} alt="Logo" className="w-12 h-12 object-contain" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-12 h-12 bg-netsuite-blue/10 rounded flex items-center justify-center text-netsuite-blue">
                <Logo className="w-8 h-8" />
              </div>
            )}
            <div>
              <h2 className="text-2xl font-sans font-bold text-netsuite-blue">{settings.companyName || settings.organizationName}</h2>
              <p className="text-[10px] font-sans text-gray-400 uppercase tracking-widest">New Payment Voucher</p>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded transition-colors font-sans text-sm"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="flex items-center gap-2 bg-netsuite-blue text-white px-6 py-2 rounded hover:bg-netsuite-blue-dark transition-colors font-sans text-sm shadow-sm"
          >
            <Save size={18} />
            Save Voucher
          </button>
        </div>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-red-50 border border-red-200 text-red-600 px-6 py-4 rounded flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="font-sans text-xs uppercase tracking-wider">{error}</span>
            </div>
            <button onClick={() => setError(null)} className="hover:bg-red-100 p-1 rounded">
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit} className="space-y-8 bg-white p-8 border border-gray-200 rounded shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">CPV No.</label>
            <input
              type="text"
              name="voucherNumber"
              readOnly
              value={formData.voucherNumber}
              className="w-full border-b border-gray-100 p-2 font-sans text-sm bg-gray-50 text-gray-400 cursor-not-allowed"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">Date</label>
            <input
              type="date"
              name="date"
              required
              value={formData.date}
              onChange={handleChange}
              className="w-full border-b border-gray-200 p-2 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">Check Number</label>
            <input
              type="text"
              name="checkNumber"
              placeholder="e.g. CHQ-12345"
              value={formData.checkNumber}
              onChange={handleChange}
              className="w-full border-b border-gray-200 p-2 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">Amount (Local)</label>
            <input
              type="number"
              step="0.01"
              name="amount"
              required
              placeholder="0.00"
              value={formData.amount}
              onChange={handleChange}
              className="w-full border-b border-gray-200 p-2 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">Exchange Rate (1 USD = ?)</label>
            <input
              type="number"
              step="0.000001"
              name="exchangeRate"
              placeholder="e.g. 54.5"
              value={formData.exchangeRate}
              onChange={handleChange}
              className="w-full border-b border-gray-200 p-2 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">Payee</label>
          <select
            name="payee"
            required
            value={formData.payee}
            onChange={handleChange}
            className="w-full border-b border-gray-200 p-2 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors bg-transparent"
          >
            <option value="">Select Payee</option>
            {payees.map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] uppercase font-sans tracking-widest text-gray-500">Account Details / Description</label>
          <textarea
            name="accountDetails"
            required
            placeholder="Purpose of payment, account number, etc."
            value={formData.accountDetails}
            onChange={handleChange}
            rows={2}
            className="w-full border border-gray-200 p-3 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors rounded"
          />
        </div>

        {/* Accounting Entries Section */}
        <div className="space-y-4 pt-6 border-t border-gray-100">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold uppercase tracking-widest text-netsuite-blue font-sans">Accounting Entries</h3>
            <button
              type="button"
              onClick={addEntry}
              className="flex items-center gap-1 text-[10px] font-sans font-bold uppercase tracking-widest text-netsuite-blue hover:underline"
            >
              <Plus size={14} /> Add Line
            </button>
          </div>
          
          <div className="border border-gray-200 rounded overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 text-[10px] uppercase font-sans tracking-widest text-gray-400 border-b border-gray-200">
                  <th className="p-2 w-32">Account Code</th>
                  <th className="p-2">Description</th>
                  <th className="p-2 w-24 text-right">Debit</th>
                  <th className="p-2 w-24 text-right">Credit</th>
                  {formData.exchangeRate && (
                    <>
                      <th className="p-2 w-24 text-right">Debit (USD)</th>
                      <th className="p-2 w-24 text-right">Credit (USD)</th>
                    </>
                  )}
                  <th className="p-2 w-10"></th>
                </tr>
              </thead>
              <tbody className="font-sans text-sm">
                {entries.map((entry, index) => (
                  <tr key={index} className="border-b border-gray-100 last:border-0 hover:bg-gray-50 transition-colors">
                    <td className="p-1">
                      <select
                        value={entry.accountCode}
                        onChange={(e) => {
                          const code = e.target.value;
                          const updates: Partial<AccountingEntry> = { accountCode: code };
                          handleEntryChange(index, updates);
                        }}
                        className="w-full p-1 border-b border-transparent focus:border-netsuite-blue focus:outline-none bg-transparent text-xs"
                      >
                        <option value="">Select Code</option>
                        {accounts.map(a => <option key={a.id} value={a.code}>{a.code} - {a.name}</option>)}
                      </select>
                    </td>
                    <td className="p-1">
                      <input
                        type="text"
                        value={entry.description}
                        onChange={(e) => handleEntryChange(index, { description: e.target.value })}
                        className="w-full p-1 border-b border-transparent focus:border-netsuite-blue focus:outline-none text-xs"
                        placeholder="Description"
                      />
                    </td>
                    <td className="p-1">
                      <input
                        type="number"
                        step="0.01"
                        value={entry.debit}
                        onChange={(e) => handleEntryChange(index, { debit: parseFloat(e.target.value) || 0 })}
                        className="w-full p-1 text-right border-b border-transparent focus:border-netsuite-blue focus:outline-none text-xs"
                      />
                    </td>
                    <td className="p-1">
                      <input
                        type="number"
                        step="0.01"
                        value={entry.credit}
                        onChange={(e) => handleEntryChange(index, { credit: parseFloat(e.target.value) || 0 })}
                        className="w-full p-1 text-right border-b border-transparent focus:border-netsuite-blue focus:outline-none text-xs"
                      />
                    </td>
                    {formData.exchangeRate && (
                      <>
                        <td className="p-1 text-right text-gray-400 text-[10px]">
                          {entry.debitUSD?.toFixed(2) || '0.00'}
                        </td>
                        <td className="p-1 text-right text-gray-400 text-[10px]">
                          {entry.creditUSD?.toFixed(2) || '0.00'}
                        </td>
                      </>
                    )}
                    <td className="p-1 text-center">
                      <button
                        type="button"
                        onClick={() => removeEntry(index)}
                        className="text-gray-300 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-gray-50/50 font-bold text-xs border-t border-gray-200">
                  <td colSpan={2} className="p-2 text-right uppercase tracking-widest text-gray-400 font-sans">Totals</td>
                  <td className="p-2 text-right text-netsuite-blue font-sans">{totalDebit.toFixed(2)}</td>
                  <td className="p-2 text-right text-netsuite-blue font-sans">{totalCredit.toFixed(2)}</td>
                  {formData.exchangeRate && (
                    <>
                      <td className="p-2 text-right text-gray-400 font-sans">{(totalDebit / parseFloat(formData.exchangeRate)).toFixed(2)}</td>
                      <td className="p-2 text-right text-gray-400 font-sans">{(totalCredit / parseFloat(formData.exchangeRate)).toFixed(2)}</td>
                    </>
                  )}
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
          {totalDebit !== totalCredit && (
            <p className="text-[10px] text-red-500 font-sans italic">Warning: Debits and Credits are not balanced.</p>
          )}
        </div>

        {/* Attachments Section */}
        <div className="space-y-4 pt-6 border-t border-gray-100">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold uppercase tracking-widest text-netsuite-blue font-sans">Source Documents / Attachments</h3>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1 text-[10px] font-sans font-bold uppercase tracking-widest text-netsuite-blue hover:underline"
            >
              <Paperclip size={14} /> Attach Files
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,application/pdf"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
          
          {attachments.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {attachments.map((file, index) => (
                <div key={index} className="relative group bg-gray-50 rounded p-2 border border-gray-100">
                  {file.startsWith('data:image/') ? (
                    <img src={file} alt={`Attachment ${index + 1}`} className="w-full h-24 object-cover rounded" />
                  ) : (
                    <div className="w-full h-24 flex items-center justify-center bg-gray-100 rounded">
                      <FileImage className="text-gray-400" size={32} />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => removeAttachment(index)}
                    className="absolute -top-2 -right-2 bg-white text-red-500 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <XCircle size={18} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[10px] text-gray-400 italic font-sans">No documents attached. Attach invoices or receipts for verification.</p>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6 border-t border-gray-100">
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-400">Prepared By</label>
            <input
              type="text"
              name="preparedBy"
              required
              placeholder="Name of preparer"
              value={formData.preparedBy}
              onChange={handleChange}
              className="w-full border-b border-gray-200 p-1 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-sans tracking-widest text-gray-400">Received By</label>
            <input
              type="text"
              name="receivedBy"
              required
              placeholder="Name of receiver"
              value={formData.receivedBy}
              onChange={handleChange}
              className="w-full border-b border-gray-200 p-1 font-sans text-sm focus:outline-none focus:border-netsuite-blue transition-colors"
            />
          </div>
        </div>

        <div className="flex justify-end gap-4 pt-8">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-2 font-sans text-sm text-gray-500 hover:text-gray-900 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 bg-netsuite-blue text-white px-8 py-2 rounded hover:bg-netsuite-blue-dark transition-colors font-sans text-sm shadow-sm active:scale-95 transform"
          >
            <Save size={16} />
            Save Voucher
          </button>
        </div>
      </form>
    </div>
  );
}
