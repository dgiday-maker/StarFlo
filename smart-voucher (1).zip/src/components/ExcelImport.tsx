import React, { useRef } from 'react';
import * as XLSX from 'xlsx';
import { Upload, FileSpreadsheet } from 'lucide-react';

interface ExcelImportProps<T> {
  onImport: (data: T[]) => void;
  template: string[];
  title: string;
}

export default function ExcelImport<T>({ onImport, template, title }: ExcelImportProps<T>) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const bstr = event.target?.result;
      const workbook = XLSX.read(bstr, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet) as any[];
      
      // Basic validation: check if required columns exist
      if (data.length > 0) {
        const headers = Object.keys(data[0]);
        const missing = template.filter(t => !headers.includes(t));
        if (missing.length > 0) {
          alert(`Missing columns: ${missing.join(', ')}`);
          return;
        }
      }

      onImport(data);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsBinaryString(file);
  };

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([
      template.reduce((acc, curr) => ({ ...acc, [curr]: '' }), {})
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, `${title}_Template.xlsx`);
  };

  return (
    <div className="flex flex-col gap-4 p-6 bg-netsuite-gray rounded border border-gray-200">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-netsuite-blue">
          <FileSpreadsheet size={20} />
          <h3 className="font-bold font-sans text-sm">Excel Import</h3>
        </div>
        <button
          onClick={downloadTemplate}
          className="text-xs text-netsuite-blue hover:underline font-sans font-bold"
        >
          Download Template
        </button>
      </div>
      
      <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded cursor-pointer hover:bg-white hover:border-netsuite-blue/40 transition-all">
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <Upload className="w-8 h-8 mb-3 text-gray-400" />
          <p className="mb-2 text-sm text-gray-600 font-sans">
            <span className="font-bold text-netsuite-blue">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-gray-400 font-sans">XLSX or CSV files only</p>
        </div>
        <input 
          ref={fileInputRef}
          type="file" 
          className="hidden" 
          accept=".xlsx, .xls, .csv"
          onChange={handleFileUpload}
        />
      </label>
    </div>
  );
}
