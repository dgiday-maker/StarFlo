import React, { useState, useRef } from 'react';
import { UserProfile, UserRole, PrintSettings } from '../types';
import { Shield, User, Save, ArrowLeft, Upload, CheckCircle2, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface ProfileSettingsProps {
  profile: UserProfile;
  settings: PrintSettings;
  onUpdate: (updates: Partial<UserProfile>) => Promise<void>;
  onUpdateSettings: (updates: Partial<PrintSettings>) => Promise<void>;
  onBack: () => void;
  isAdmin: boolean;
}

export default function ProfileSettings({ profile, settings, onUpdate, onUpdateSettings, onBack, isAdmin }: ProfileSettingsProps) {
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [signatureUrl, setSignatureUrl] = useState(profile.signatureUrl || '');
  const [orgName, setOrgName] = useState(settings.organizationName || '');
  const [companyName, setCompanyName] = useState(settings.companyName || '');
  const [companyLogo, setCompanyLogo] = useState(settings.companyLogo || '');
  const [bankName, setBankName] = useState(settings.bankName || '');
  const [bankAccountCode, setBankAccountCode] = useState(settings.bankAccountCode || '');
  const [publicUrl, setPublicUrl] = useState(settings.publicUrl || '');
  const [defaultPreparedBy, setDefaultPreparedBy] = useState(settings.defaultPreparedBy || '');
  const [defaultAuthorizedBy1, setDefaultAuthorizedBy1] = useState(settings.defaultAuthorizedBy1 || '');
  const [defaultAuthorizedBy2, setDefaultAuthorizedBy2] = useState(settings.defaultAuthorizedBy2 || '');
  const [defaultAuthorizedBy3, setDefaultAuthorizedBy3] = useState(settings.defaultAuthorizedBy3 || '');
  const [defaultReceivedBy, setDefaultReceivedBy] = useState(settings.defaultReceivedBy || '');
  const [voucherNumberPattern, setVoucherNumberPattern] = useState(settings.voucherNumberPattern || 'CPV-2024-');
  const [checkNumberPattern, setCheckNumberPattern] = useState(settings.checkNumberPattern || '');
  const [nextVoucherNumber, setNextVoucherNumber] = useState(settings.nextVoucherNumber || 1);
  const [nextCheckNumber, setNextCheckNumber] = useState(settings.nextCheckNumber || 1);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const getInitials = (name: string): string => {
    if (!name) return 'U';
    const parts = name.split(' ').filter(Boolean);
    if (parts.length === 0) return 'U';
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await onUpdate({ displayName, signatureUrl });
      if (isAdmin) {
        await onUpdateSettings({ 
          organizationName: orgName, 
          companyName,
          companyLogo,
          bankName,
          bankAccountCode,
          publicUrl,
          defaultPreparedBy,
          defaultAuthorizedBy1,
          defaultAuthorizedBy2,
          defaultAuthorizedBy3,
          defaultReceivedBy,
          voucherNumberPattern,
          checkNumberPattern,
          nextVoucherNumber: Number(nextVoucherNumber),
          nextCheckNumber: Number(nextCheckNumber)
        });
      }
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Update failed:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSignatureUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogoImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCompanyLogo(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-netsuite-blue transition-colors font-sans text-sm"
        >
          <ArrowLeft size={18} />
          Back to Dashboard
        </button>
        <h2 className="text-2xl font-sans font-bold text-gray-900">User Profile & Security</h2>
      </div>

      <div className="space-y-6">
        {/* Profile Card */}
        <div className="bg-white p-8 rounded border border-gray-200 shadow-sm">
          <div className="flex items-center gap-6 mb-8">
            <div className="w-20 h-20 bg-netsuite-blue rounded flex items-center justify-center relative border border-gray-100 overflow-hidden">
              <span className="text-2xl font-bold text-white">
                {getInitials(profile.displayName || profile.email || 'U')}
              </span>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-white rounded shadow-md flex items-center justify-center border border-gray-100">
                <Shield size={16} className="text-netsuite-blue" />
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 font-sans">{profile.displayName}</h3>
              <p className="text-gray-500 text-sm font-sans">{profile.email}</p>
              <div className="mt-2 flex items-center gap-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-netsuite-blue/5 text-netsuite-blue rounded text-[10px] font-sans uppercase tracking-wider font-bold">
                  Role: {profile.role}
                </div>
                <div className={cn(
                  "inline-flex items-center gap-2 px-3 py-1 rounded text-[10px] font-sans uppercase tracking-wider font-bold border",
                  profile.active 
                    ? "bg-emerald-50 text-emerald-600 border-emerald-100" 
                    : "bg-red-50 text-red-600 border-red-100"
                )}>
                  Status: {profile.active ? 'Active' : 'Inactive'}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                placeholder="Enter your full name"
              />
            </div>

            <div>
              <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Digital Signature (Import Image)</label>
              <div className="flex flex-col gap-4">
                <div className="flex gap-4">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 flex items-center justify-center gap-2 bg-gray-50 border-2 border-dashed border-gray-200 rounded p-8 hover:border-netsuite-blue/40 hover:bg-netsuite-blue/5 transition-all group"
                  >
                    <Upload className="w-6 h-6 text-gray-400 group-hover:text-netsuite-blue" />
                    <span className="text-sm text-gray-500 group-hover:text-netsuite-blue font-sans">Click to import signature image</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileImport}
                    className="hidden"
                  />
                </div>
                {signatureUrl && (
                  <div className="bg-gray-50 p-4 rounded border border-gray-200">
                    <p className="text-[10px] font-sans text-gray-400 uppercase mb-2">Preview</p>
                    <div className="h-24 bg-white rounded border border-gray-100 flex items-center justify-center p-4">
                      <img src={signatureUrl} alt="Signature Preview" className="max-h-full object-contain" />
                    </div>
                    <button
                      onClick={() => setSignatureUrl('')}
                      className="mt-2 text-xs text-red-500 hover:underline font-sans"
                    >
                      Remove Signature
                    </button>
                  </div>
                )}
              </div>
            </div>

            {isAdmin && (
              <div className="pt-6 border-t border-gray-100">
                <h4 className="text-sm font-bold text-netsuite-blue mb-4 font-sans">System Configuration</h4>
                <div>
                  <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Organization Name (System Title)</label>
                  <input
                    type="text"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm mb-4"
                    placeholder="Enter organization name"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Company Name (Printed on Voucher)</label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm mb-4"
                    placeholder="Enter company name for vouchers"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Company Logo (Printed on Voucher)</label>
                  <div className="flex flex-col gap-4 mb-4">
                    <div className="flex gap-4">
                      <button
                        onClick={() => logoInputRef.current?.click()}
                        className="flex-1 flex items-center justify-center gap-2 bg-gray-50 border-2 border-dashed border-gray-200 rounded p-4 hover:border-netsuite-blue/40 hover:bg-netsuite-blue/5 transition-all group"
                      >
                        <ImageIcon className="w-5 h-5 text-gray-400 group-hover:text-netsuite-blue" />
                        <span className="text-xs text-gray-500 group-hover:text-netsuite-blue font-sans">Click to import company logo</span>
                      </button>
                      <input
                        ref={logoInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleLogoImport}
                        className="hidden"
                      />
                    </div>
                    {companyLogo && (
                      <div className="bg-gray-50 p-4 rounded border border-gray-200">
                        <div className="h-16 bg-white rounded border border-gray-100 flex items-center justify-center p-2">
                          <img src={companyLogo} alt="Logo Preview" className="max-h-full object-contain" />
                        </div>
                        <button
                          onClick={() => setCompanyLogo('')}
                          className="mt-2 text-[10px] text-red-500 hover:underline font-sans"
                        >
                          Remove Logo
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Bank Name</label>
                    <input
                      type="text"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                      placeholder="e.g. Commercial Bank"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Bank Account Code</label>
                    <input
                      type="text"
                      value={bankAccountCode}
                      onChange={(e) => setBankAccountCode(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                      placeholder="e.g. 1000123456"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Public App URL (Shared Link)</label>
                  <input
                    type="text"
                    value={publicUrl}
                    onChange={(e) => setPublicUrl(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                    placeholder="e.g. https://ais-pre-...run.app"
                  />
                  <p className="mt-1 text-[10px] text-gray-400 font-sans italic">
                    Set this to your "Shared App URL" to ensure "Copy Link" and "Open in New Tab" work correctly for all users.
                  </p>
                </div>

                <div className="pt-6 border-t border-gray-100 mt-6">
                  <h4 className="text-sm font-bold text-netsuite-blue mb-4 font-sans">Default Signature Names (Manual Approval)</h4>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Default Prepared By</label>
                      <input
                        type="text"
                        value={defaultPreparedBy}
                        onChange={(e) => setDefaultPreparedBy(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="Name of preparer"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Default Received By</label>
                      <input
                        type="text"
                        value={defaultReceivedBy}
                        onChange={(e) => setDefaultReceivedBy(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="Name of receiver (optional)"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Authorized By 1</label>
                      <input
                        type="text"
                        value={defaultAuthorizedBy1}
                        onChange={(e) => setDefaultAuthorizedBy1(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="Approver 1"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Authorized By 2</label>
                      <input
                        type="text"
                        value={defaultAuthorizedBy2}
                        onChange={(e) => setDefaultAuthorizedBy2(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="Approver 2"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Authorized By 3</label>
                      <input
                        type="text"
                        value={defaultAuthorizedBy3}
                        onChange={(e) => setDefaultAuthorizedBy3(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="Approver 3"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-gray-100 mt-6">
                  <h4 className="text-sm font-bold text-netsuite-blue mb-4 font-sans">Voucher & Check Numbering Series</h4>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">CPV Pattern</label>
                      <input
                        type="text"
                        value={voucherNumberPattern}
                        onChange={(e) => setVoucherNumberPattern(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="e.g. CPV-2024-"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Check No. Pattern</label>
                      <input
                        type="text"
                        value={checkNumberPattern}
                        onChange={(e) => setCheckNumberPattern(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                        placeholder="e.g. CHQ-"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Next CPV No.</label>
                      <input
                        type="number"
                        value={nextVoucherNumber}
                        onChange={(e) => setNextVoucherNumber(parseInt(e.target.value) || 0)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans uppercase tracking-widest text-gray-400 mb-2">Next Check No.</label>
                      <input
                        type="number"
                        value={nextCheckNumber}
                        onChange={(e) => setNextCheckNumber(parseInt(e.target.value) || 0)}
                        className="w-full bg-gray-50 border border-gray-200 rounded px-4 py-2 focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue outline-none transition-all font-sans text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {success && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center gap-2 text-green-600 text-sm font-medium font-sans"
                >
                  <CheckCircle2 size={16} />
                  Profile updated successfully
                </motion.div>
              )}
            </div>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 bg-netsuite-blue text-white px-8 py-2 rounded font-medium hover:bg-netsuite-blue-dark transition-all shadow-sm disabled:opacity-50 font-sans text-sm"
            >
              {saving ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Save size={18} />
              )}
              Save Changes
            </button>
          </div>
        </div>

        {/* Security Info */}
        <div className="bg-netsuite-blue/5 p-6 rounded border border-netsuite-blue/10">
          <div className="flex gap-4">
            <Shield className="text-netsuite-blue shrink-0" size={24} />
            <div>
              <h4 className="font-bold text-netsuite-blue mb-1 font-sans">Security & Role Access</h4>
              <p className="text-sm text-netsuite-blue/70 leading-relaxed font-sans">
                Your account is assigned the <span className="font-bold">{profile.role}</span> role. 
                This determines which actions you can perform in the voucher workflow. 
                Admins can modify roles for other users.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
