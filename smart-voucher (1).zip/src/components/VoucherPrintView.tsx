import React, { useRef } from 'react';
import { Voucher, PrintSettings, OffsetField } from '../types';
import { format } from 'date-fns';
import { formatDate, numberToWords, formatCurrency } from '../lib/utils';
import { ArrowLeft, Printer, ExternalLink, ArrowUp, ArrowDown, ArrowLeft as ArrowLeftIcon, ArrowRight, RotateCcw } from 'lucide-react';

interface VoucherPrintViewProps {
  voucher: Voucher;
  settings: PrintSettings;
  onAdjust: (field: OffsetField, axis: 'top' | 'left', delta: number) => void;
  onReset: () => void;
  onBack: () => void;
}

const AdjustmentControls = ({ 
  label, 
  field, 
  settings, 
  onAdjust 
}: { 
  label: string, 
  field: OffsetField, 
  settings: PrintSettings,
  onAdjust: (field: OffsetField, axis: 'top' | 'left', delta: number) => void
}) => {
  const handleBtnClick = (axis: 'top' | 'left', delta: number) => {
    onAdjust(field, axis, delta);
  };

  const offset = (settings[field] || { top: 0, left: 0 }) as { top: number, left: number };

  return (
    <div className="bg-white p-1.5 border border-gray-200 rounded flex items-center justify-between gap-2 relative z-50">
      <div className="flex-1 min-w-0">
        <p className="text-[8px] uppercase font-sans font-bold text-gray-500 tracking-wider truncate leading-none mb-1">{label}</p>
        <div className="text-[8px] font-sans text-netsuite-blue/70 flex gap-1.5 leading-none">
          <span>T:{offset.top}</span>
          <span>L:{offset.left}</span>
        </div>
      </div>
      <div className="flex items-center gap-0.5">
        <button 
          type="button" 
          onClick={() => handleBtnClick('left', -2)} 
          className="p-1 hover:bg-netsuite-blue/10 rounded border border-transparent hover:border-netsuite-blue/20 active:bg-netsuite-blue/20 text-netsuite-blue"
          title="Move Left"
        >
          <ArrowLeftIcon size={10} />
        </button>
        <button 
          type="button" 
          onClick={() => handleBtnClick('top', -2)} 
          className="p-1 hover:bg-netsuite-blue/10 rounded border border-transparent hover:border-netsuite-blue/20 active:bg-netsuite-blue/20 text-netsuite-blue"
          title="Move Up"
        >
          <ArrowUp size={10} />
        </button>
        <button 
          type="button" 
          onClick={() => handleBtnClick('top', 2)} 
          className="p-1 hover:bg-netsuite-blue/10 rounded border border-transparent hover:border-netsuite-blue/20 active:bg-netsuite-blue/20 text-netsuite-blue"
          title="Move Down"
        >
          <ArrowDown size={10} />
        </button>
        <button 
          type="button" 
          onClick={() => handleBtnClick('left', 2)} 
          className="p-1 hover:bg-netsuite-blue/10 rounded border border-transparent hover:border-netsuite-blue/20 active:bg-netsuite-blue/20 text-netsuite-blue"
          title="Move Right"
        >
          <ArrowRight size={10} />
        </button>
      </div>
    </div>
  );
};

export default function VoucherPrintView({ voucher, settings, onAdjust, onReset, onBack }: VoucherPrintViewProps) {
  const [debugMode, setDebugMode] = React.useState(false);
  console.log('VoucherPrintView rendering with voucher:', voucher);
  console.log('VoucherPrintView rendering with settings:', settings);

  const handlePrint = () => {
    console.log('Print Now button clicked - triggering direct window.print()');
    window.print();
  };

  const toggleDebug = () => {
    setDebugMode(!debugMode);
    if (!debugMode) {
      setTimeout(() => setDebugMode(false), 3000);
    }
  };

  const handleOpenNewTab = () => {
    console.log('Opening in new tab for printing');
    window.open(window.location.href, '_blank');
  };

  if (!voucher) {
    return (
      <div className="p-8 text-center text-red-500 font-mono">
        Error: No voucher data selected for printing.
      </div>
    );
  }

  return (
    <div className={`flex gap-8 max-w-6xl mx-auto relative ${debugMode ? 'debug-print' : ''}`}>
      {/* 
        ACTUAL PRINT SHEET 
        This is hidden on screen but visible to the printer.
        It uses the .print-sheet class defined in App.tsx.
      */}
      <div className="print-sheet">
        <div 
          className="absolute font-mono text-[16px] font-bold text-black"
          style={{ top: `${(settings.checkNumberOffset?.top ?? 20)}px`, left: `${(settings.checkNumberOffset?.left ?? 550)}px` }}
        >
          {voucher.checkNumber || ''}
        </div>
        <div 
          className="absolute font-mono text-[18px] font-bold text-black"
          style={{ top: `${(settings.date?.top ?? 40)}px`, left: `${(settings.date?.left ?? 500)}px` }}
        >
          {formatDate(voucher.date)}
        </div>
        <div 
          className="absolute font-serif text-[20px] font-bold text-black"
          style={{ top: `${(settings.payee?.top ?? 100)}px`, left: `${(settings.payee?.left ?? 100)}px` }}
        >
          {voucher.payee || 'PAYEE NAME'}
        </div>
        <div 
          className="absolute font-mono text-[20px] font-bold border-2 border-black px-3 py-1 text-black"
          style={{ top: `${(settings.amountFigures?.top ?? 100)}px`, left: `${(settings.amountFigures?.left ?? 550)}px` }}
        >
          {voucher.amount !== undefined ? formatCurrency(voucher.amount).replace('$', '') : '0.00'}
        </div>
        <div 
          className="absolute font-serif italic text-[14px] max-w-[550px] leading-tight text-black"
          style={{ top: `${(settings.amountWords?.top ?? 150)}px`, left: `${(settings.amountWords?.left ?? 60)}px` }}
        >
          {voucher.amount !== undefined ? numberToWords(voucher.amount) : 'Zero Dollars and 00/100 Cents'}
        </div>
      </div>

      {/* Left Panel: Adjustments */}
      <div className="w-64 space-y-2 print-hidden relative z-40">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 font-sans">Alignment</h3>
          <button 
            type="button" 
            onClick={() => { console.log('Reset clicked'); onReset(); }} 
            className="text-gray-400 hover:text-red-600 transition-colors relative z-50 cursor-pointer" 
            title="Reset to Default"
          >
            <RotateCcw size={14} />
          </button>
        </div>
        <AdjustmentControls label="Date Field" field="date" settings={settings} onAdjust={onAdjust} />
        <AdjustmentControls label="Payee Name" field="payee" settings={settings} onAdjust={onAdjust} />
        <AdjustmentControls label="Amount (Figures)" field="amountFigures" settings={settings} onAdjust={onAdjust} />
        <AdjustmentControls label="Amount (Words)" field="amountWords" settings={settings} onAdjust={onAdjust} />
        <AdjustmentControls label="Check Number" field="checkNumberOffset" settings={settings} onAdjust={onAdjust} />
        
        <div className="p-3 bg-netsuite-gray text-gray-700 rounded border border-gray-200 text-[9px] font-sans leading-relaxed shadow-sm">
          <p className="font-bold mb-0.5 uppercase text-[8px] text-gray-500">Pro Tip:</p>
          Use these buttons to align the text with your pre-printed check. Settings are saved automatically.
        </div>
      </div>

      {/* Right Panel: Preview & Print */}
      <div className="flex-1 space-y-8 relative z-30">
        <div className="flex justify-between items-center print-hidden">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => { console.log('Back clicked'); onBack(); }}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors relative z-50 cursor-pointer"
            >
              <ArrowLeft size={20} />
            </button>
            <h2 className="text-xl font-sans font-bold text-gray-900">Voucher Print Preview</h2>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={toggleDebug}
              className="flex items-center gap-2 bg-white border border-gray-300 text-gray-700 px-3 py-1.5 rounded hover:bg-gray-50 transition-colors font-sans text-xs relative z-50 cursor-pointer"
              title="Show print sheet on screen for 3 seconds"
            >
              Test View
            </button>
            <button
              type="button"
              onClick={handleOpenNewTab}
              className="flex items-center gap-2 bg-white border border-gray-300 text-gray-700 px-3 py-1.5 rounded hover:bg-gray-50 transition-colors font-sans text-xs relative z-50 cursor-pointer"
              title="Open app in a new tab to enable printing if it's blocked in the preview"
            >
              <ExternalLink size={14} />
              Open in New Tab
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-2 bg-netsuite-blue text-white px-4 py-1.5 rounded hover:bg-netsuite-blue-dark transition-colors font-sans text-xs shadow-sm active:scale-95 transform relative z-50 cursor-pointer"
            >
              <Printer size={14} />
              Print Now
            </button>
          </div>
        </div>

        <div className="bg-gray-50 p-12 rounded flex justify-center print-hidden border border-gray-200">
          <div 
            className="relative bg-white border border-gray-300 shadow-md overflow-hidden"
            style={{ width: '672px', height: '288px' }}
          >
            <div 
              className="absolute font-sans text-sm font-bold text-netsuite-blue"
              style={{ top: `${(settings.checkNumberOffset?.top ?? 20)}px`, left: `${(settings.checkNumberOffset?.left ?? 550)}px` }}
            >
              {voucher.checkNumber}
            </div>
            <div 
              className="absolute font-sans text-lg font-bold text-netsuite-blue"
              style={{ top: `${(settings.date?.top ?? 40)}px`, left: `${(settings.date?.left ?? 500)}px` }}
            >
              {format(new Date(voucher.date), 'MM / dd / yyyy')}
            </div>
            <div 
              className="absolute font-sans text-xl font-bold text-netsuite-blue max-w-[400px] truncate"
              style={{ top: `${(settings.payee?.top ?? 100)}px`, left: `${(settings.payee?.left ?? 100)}px` }}
            >
              {voucher.payee}
            </div>
            <div 
              className="absolute font-sans text-xl font-bold text-netsuite-blue border border-netsuite-blue/30 px-3 py-1 bg-netsuite-blue/5"
              style={{ top: `${(settings.amountFigures?.top ?? 100)}px`, left: `${(settings.amountFigures?.left ?? 550)}px` }}
            >
              {formatCurrency(voucher.amount).replace('$', '')}
            </div>
            <div 
              className="absolute font-sans italic text-sm text-netsuite-blue max-w-[550px] leading-tight"
              style={{ top: `${(settings.amountWords?.top ?? 150)}px`, left: `${(settings.amountWords?.left ?? 60)}px` }}
            >
              {numberToWords(voucher.amount)}
            </div>
            
            {/* Guidelines */}
            <div className="absolute inset-0 border border-dashed border-gray-200 pointer-events-none flex items-center justify-center opacity-30">
              <span className="text-gray-400 font-sans text-[10px] uppercase tracking-widest">3" x 7" Check Area</span>
            </div>
          </div>
        </div>
      </div>
      <style dangerouslySetInnerHTML={{ __html: checkPrintStyles }} />
    </div>
  );
}

const checkPrintStyles = `
  @media print {
    @page {
      size: 7in 3in;
      margin: 0;
    }
  }
`;
