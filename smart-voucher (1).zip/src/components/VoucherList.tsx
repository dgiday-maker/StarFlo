import React, { useState, useMemo } from 'react';
import { Voucher, VoucherStatus, UserRole } from '../types';
import { format } from 'date-fns';
import { Printer, Trash2, Eye, Plus, CheckCircle2, ShieldCheck, Clock, FileText, XCircle, Search, ArrowUpDown, Filter } from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { User } from 'firebase/auth';

interface VoucherListProps {
  vouchers: Voucher[];
  onPrint: (voucher: Voucher) => void;
  onFullPrint: (voucher: Voucher) => void;
  onPreview: (voucher: Voucher) => void;
  onDelete: (id: string) => void;
  onVerify: (id: string) => void;
  onApprove: (id: string) => void;
  onNew: () => void;
  currentUser: User | null;
  userRole: UserRole;
}

type SortField = 'date' | 'payee' | 'amount' | 'status';
type SortOrder = 'asc' | 'desc';

const StatusBadge = ({ status }: { status: VoucherStatus }) => {
  const styles = {
    draft: 'bg-gray-100 text-gray-600 border-gray-200',
    prepared: 'bg-blue-50 text-blue-600 border-blue-100',
    verified: 'bg-amber-50 text-amber-600 border-amber-100',
    approved: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    void: 'bg-red-50 text-red-600 border-red-100',
  };

  const icons = {
    draft: FileText,
    prepared: Clock,
    verified: CheckCircle2,
    approved: ShieldCheck,
    void: XCircle,
  };

  const Icon = icons[status];

  return (
    <span className={cn(
      "px-2 py-0.5 rounded-full text-[9px] font-sans font-bold uppercase border tracking-wider flex items-center gap-1 w-fit",
      styles[status]
    )}>
      <Icon size={10} />
      {status}
    </span>
  );
};

export default function VoucherList({ 
  vouchers, 
  onPrint, 
  onFullPrint, 
  onPreview,
  onDelete, 
  onVerify, 
  onApprove, 
  onNew, 
  currentUser,
  userRole 
}: VoucherListProps) {
  const [activeTab, setActiveTab] = useState<VoucherStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const filteredAndSortedVouchers = useMemo(() => {
    let result = vouchers;

    // Filter by Tab
    if (activeTab !== 'all') {
      result = result.filter(v => v.status === activeTab);
    }

    // Search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(v => 
        v.payee.toLowerCase().includes(query) || 
        v.id.toLowerCase().includes(query) ||
        (v.voucherNumber && v.voucherNumber.toLowerCase().includes(query)) ||
        v.accountDetails.toLowerCase().includes(query)
      );
    }

    // Sort
    result = [...result].sort((a, b) => {
      let comparison = 0;
      if (sortField === 'date') {
        comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
      } else if (sortField === 'payee') {
        comparison = a.payee.localeCompare(b.payee);
      } else if (sortField === 'amount') {
        comparison = a.amount - b.amount;
      } else if (sortField === 'status') {
        comparison = a.status.localeCompare(b.status);
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [vouchers, activeTab, searchQuery, sortField, sortOrder]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const tabs: { id: VoucherStatus | 'all', label: string, icon: any }[] = [
    { id: 'all', label: 'All Vouchers', icon: Clock },
  ];

  const canVerify = userRole === 'verifier' || userRole === 'admin';
  const canApprove = userRole === 'approver' || userRole === 'admin';
  const canDelete = userRole === 'admin';

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex border-b border-gray-200 gap-8">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "pb-3 text-sm font-sans transition-all relative",
                activeTab === tab.id ? "text-netsuite-blue font-bold" : "text-gray-400 hover:text-gray-600"
              )}
            >
              <div className="flex items-center gap-2">
                <tab.icon size={14} />
                {tab.label}
              </div>
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-netsuite-blue" />
              )}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search vouchers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10 py-2 bg-white border border-gray-200 rounded text-sm font-sans focus:outline-none focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all w-full md:w-64"
          />
          <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300" size={14} />
        </div>
      </div>

      <div className="bg-white border border-gray-200 overflow-hidden rounded shadow-sm">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">
                <button onClick={() => toggleSort('date')} className="flex items-center gap-1 hover:text-gray-600 transition-colors">
                  Date <ArrowUpDown size={10} />
                </button>
              </th>
              <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">
                CPV No
              </th>
              <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">
                <button onClick={() => toggleSort('payee')} className="flex items-center gap-1 hover:text-gray-600 transition-colors">
                  Payee <ArrowUpDown size={10} />
                </button>
              </th>
              <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400 text-right">
                <button onClick={() => toggleSort('amount')} className="flex items-center gap-1 justify-end w-full hover:text-gray-600 transition-colors">
                  Amount <ArrowUpDown size={10} />
                </button>
              </th>
              <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400">
                <button onClick={() => toggleSort('status')} className="flex items-center gap-1 hover:text-gray-600 transition-colors">
                  Status <ArrowUpDown size={10} />
                </button>
              </th>
              <th className="p-4 font-sans text-[10px] uppercase tracking-widest text-gray-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {filteredAndSortedVouchers.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-12 text-center text-gray-400 italic font-sans">
                  No records found in this stage.
                </td>
              </tr>
            ) : (
              filteredAndSortedVouchers.map((v, index) => (
                <tr 
                  key={v.id} 
                  className={cn(
                    "border-t border-gray-100 hover:bg-netsuite-blue/[0.02] transition-colors group",
                    index % 2 === 1 ? "bg-gray-50/[0.3]" : "bg-white"
                  )}
                >
                  <td className="p-4 text-gray-500 font-sans text-xs">{format(new Date(v.date), 'MMM dd, yyyy')}</td>
                  <td className="p-4 font-bold text-netsuite-blue font-sans text-xs">
                    {v.voucherNumber || v.id.slice(-8).toUpperCase()}
                  </td>
                  <td className="p-4 font-bold text-gray-900 font-sans">{v.payee}</td>
                  <td className="p-4 text-right font-bold text-netsuite-blue font-sans">{formatCurrency(v.amount)}</td>
                  <td className="p-4">
                    <StatusBadge status={v.status} />
                  </td>
                  <td className="p-4">
                    <div className="flex justify-end gap-1">
                      <button
                        onClick={() => onPreview(v)}
                        className="p-2 text-gray-400 hover:text-netsuite-blue hover:bg-netsuite-blue/5 rounded transition-all"
                        title="Preview Voucher & Attachments"
                      >
                        <Eye size={16} />
                      </button>
                      <button
                        onClick={() => onPrint(v)}
                        className="p-2 text-netsuite-blue hover:bg-netsuite-blue/5 rounded transition-all"
                        title="Print Voucher"
                      >
                        <Printer size={16} />
                      </button>
                      <button
                        onClick={() => onFullPrint(v)}
                        className="p-2 text-netsuite-blue hover:bg-netsuite-blue/5 rounded transition-all"
                        title="Print Full Voucher"
                      >
                        <FileText size={16} />
                      </button>
                      {canDelete && (
                        <button
                          onClick={() => onDelete(v.id)}
                          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-all"
                          title="Delete Record"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
