import React from 'react';
import { Voucher, PrintSettings } from '../types';
import { ArrowLeft, Printer, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';
import { Logo } from './Logo';
import { numberToWords } from '../lib/numberToWords';

interface FullVoucherPrintViewProps {
  voucher: Voucher;
  settings: PrintSettings;
  onBack: () => void;
}

export default function FullVoucherPrintView({ voucher, settings, onBack }: FullVoucherPrintViewProps) {
  const handlePrint = () => {
    window.print();
  };

  const handleOpenNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  const totalDebit = voucher.entries?.reduce((sum, entry) => sum + (Number(entry.debit) || 0), 0) || 0;
  const totalCredit = voucher.entries?.reduce((sum, entry) => sum + (Number(entry.credit) || 0), 0) || 0;
  const amountInWords = numberToWords(voucher.amount);

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-xl font-sans font-bold text-gray-900">Voucher Print Preview</h2>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleOpenNewTab}
            className="flex items-center gap-2 bg-white border border-gray-300 text-gray-700 px-4 py-1.5 rounded hover:bg-gray-50 transition-colors font-sans text-xs shadow-sm"
            title="Open app in a new tab to enable printing if it's blocked in the preview"
          >
            <ExternalLink size={16} />
            Open in New Tab
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-netsuite-blue text-white px-4 py-1.5 rounded hover:bg-netsuite-blue-dark transition-colors font-sans text-xs shadow-sm"
          >
            <Printer size={16} />
            Print Full Voucher
          </button>
        </div>
      </div>

      {/* The Printable Voucher */}
      <div className="bg-white p-12 shadow-sm border border-gray-200 w-[210mm] min-h-[297mm] mx-auto print:shadow-none print:border-none print:p-0 print:m-0 print-voucher font-sans">
        <div className="space-y-10 p-4">
          {/* Header */}
          <div className="flex justify-between items-start border-b-4 border-netsuite-blue pb-8">
            <div className="flex items-center gap-6">
              {settings.companyLogo ? (
                <img src={settings.companyLogo} alt="Logo" className="w-24 h-24 object-contain" referrerPolicy="no-referrer" />
              ) : (
                <Logo className="w-20 h-20 text-netsuite-blue" />
              )}
              <div className="space-y-2">
                <h1 className="text-4xl font-sans font-bold text-netsuite-blue tracking-tight">{settings.companyName || settings.organizationName}</h1>
                <p className="text-xs font-sans uppercase tracking-[0.3em] text-gray-500 font-black">Check Payment Voucher (CPV)</p>
              </div>
            </div>
            <div className="text-right space-y-2">
              <p className="text-lg font-sans font-bold text-gray-900 bg-gray-100 px-3 py-1 rounded">VOUCHER NO: {voucher.id.slice(-8).toUpperCase()}</p>
              {voucher.checkNumber && (
                <p className="text-base font-sans font-bold text-netsuite-blue">CHECK NO: {voucher.checkNumber}</p>
              )}
              <p className="text-sm font-sans text-gray-600 uppercase font-medium">DATE: {format(new Date(voucher.date), 'dd MMMM yyyy')}</p>
            </div>
          </div>

          {/* Bank Info */}
          {(settings.bankName || settings.bankAccountCode) && (
            <div className="flex gap-12 text-xs font-sans uppercase tracking-[0.15em] text-gray-600 border-b border-gray-100 pb-6">
              {settings.bankName && (
                <p><span className="font-black text-gray-400 mr-2">Bank:</span> {settings.bankName}</p>
              )}
              {settings.bankAccountCode && (
                <p><span className="font-black text-gray-400 mr-2">Account Code:</span> {settings.bankAccountCode}</p>
              )}
            </div>
          )}

          {/* Payee Info */}
          <div className="grid grid-cols-3 gap-12">
            <div className="col-span-2 space-y-8">
              <div className="space-y-3">
                <p className="text-xs uppercase font-sans font-black text-gray-400 tracking-widest">Paid To (Payee)</p>
                <p className="text-2xl font-sans font-bold border-b-2 border-gray-100 pb-3 text-gray-900">{voucher.payee}</p>
              </div>
              <div className="space-y-3">
                <p className="text-xs uppercase font-sans font-black text-gray-400 tracking-widest">Purpose / Transaction Details</p>
                <p className="text-base font-sans border-b-2 border-gray-100 pb-3 text-gray-700 leading-relaxed font-medium">{voucher.accountDetails}</p>
              </div>
            </div>
            <div className="space-y-3">
              <p className="text-xs uppercase font-sans font-black text-gray-400 tracking-widest text-right">Total Amount (Local)</p>
              <div className="text-4xl font-sans font-bold text-netsuite-blue bg-netsuite-blue/5 p-6 rounded-lg border-2 border-netsuite-blue/10 text-right shadow-sm">
                {voucher.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              {voucher.exchangeRate && (
                <div className="text-right space-y-2 mt-4">
                  <p className="text-xs uppercase font-sans font-black text-gray-400 tracking-widest">Total Amount (USD)</p>
                  <p className="text-2xl font-sans font-bold text-gray-700">
                    $ {(voucher.amount / voucher.exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-[10px] text-gray-400 font-sans italic font-medium">Rate: 1 USD = {voucher.exchangeRate.toFixed(4)}</p>
                </div>
              )}
            </div>
          </div>

          {/* Amount in Words */}
          <div className="space-y-3 bg-gray-50 p-6 rounded-lg border-2 border-gray-100">
            <p className="text-xs uppercase font-sans font-black text-gray-400 tracking-widest">Amount in Words</p>
            <p className="text-base font-sans font-bold text-gray-800 italic leading-relaxed">
              {amountInWords} ETB
            </p>
          </div>

          {/* Accounting Entries */}
          <div className="space-y-6">
            <h3 className="text-xs font-black uppercase tracking-[0.3em] text-gray-400 font-sans">Accounting Distribution</h3>
            <div className="border-2 border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-100 text-xs uppercase font-sans font-black text-gray-600 border-b-2 border-gray-200">
                    <th className="p-4 text-left">Account Code</th>
                    <th className="p-4 text-left">Description</th>
                    <th className="p-4 text-right w-32">Debit</th>
                    <th className="p-4 text-right w-32">Credit</th>
                    {voucher.exchangeRate && (
                      <>
                        <th className="p-4 text-right w-32">Debit (USD)</th>
                        <th className="p-4 text-right w-32">Credit (USD)</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody className="text-sm font-sans font-medium">
                  {voucher.entries?.map((entry, i) => (
                    <tr key={i} className="border-b border-gray-100 last:border-0 hover:bg-gray-50/50 transition-colors">
                      <td className="p-4">
                        <span className="px-3 py-1 bg-netsuite-blue/10 text-netsuite-blue font-black rounded text-xs border border-netsuite-blue/20">
                          {entry.accountCode || 'N/A'}
                        </span>
                      </td>
                      <td className="p-4 text-gray-900">{entry.description}</td>
                      <td className="p-4 text-right text-gray-900 font-bold">{entry.debit > 0 ? entry.debit.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '-'}</td>
                      <td className="p-4 text-right text-gray-900 font-bold">{entry.credit > 0 ? entry.credit.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '-'}</td>
                      {voucher.exchangeRate && (
                        <>
                          <td className="p-4 text-right text-gray-500 italic">{(entry.debit / voucher.exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                          <td className="p-4 text-right text-gray-500 italic">{(entry.credit / voucher.exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        </>
                      )}
                    </tr>
                  ))}
                  {(!voucher.entries || voucher.entries.length === 0) && (
                    <tr>
                      <td colSpan={4} className="p-16 text-center text-gray-400 italic font-medium">No accounting entries recorded for this voucher.</td>
                    </tr>
                  )}
                </tbody>
                <tfoot className="bg-gray-100 font-black border-t-2 border-gray-200">
                  <tr className="text-sm font-sans">
                    <td colSpan={2} className="p-4 text-right uppercase text-xs text-gray-500 tracking-widest">Totals</td>
                    <td className="p-4 text-right border-l-2 border-gray-200 text-netsuite-blue text-base">{totalDebit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td className="p-4 text-right border-l-2 border-gray-200 text-netsuite-blue text-base">{totalCredit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    {voucher.exchangeRate && (
                      <>
                        <td className="p-4 text-right border-l-2 border-gray-200 text-gray-500">{(totalDebit / voucher.exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        <td className="p-4 text-right border-l-2 border-gray-200 text-gray-500">{(totalCredit / voucher.exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      </>
                    )}
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Signatures Section */}
          <div className="space-y-8 pt-12">
            {[
              { label: 'Prepared By', name: voucher.preparedBy || settings.defaultPreparedBy },
              { label: 'Authorized By 1', name: settings.defaultAuthorizedBy1 },
              { label: 'Authorized By 2', name: settings.defaultAuthorizedBy2 },
              { label: 'Authorized By 3', name: settings.defaultAuthorizedBy3 },
              { label: 'Received By', name: voucher.receivedBy || settings.defaultReceivedBy }
            ].map((sig, idx) => (
              <div key={idx} className="flex items-end gap-6 border-b-2 border-gray-100 pb-4">
                <div className="w-40">
                  <p className="text-xs uppercase font-sans font-black text-gray-900 tracking-widest">{sig.label}:</p>
                </div>
                <div className="flex-1 border-b-2 border-gray-200 min-h-[2rem] flex items-end">
                  <p className="text-lg font-sans font-bold text-netsuite-blue">
                    {sig.name || ''}
                  </p>
                </div>
                <div className="flex-1 border-b-2 border-gray-300 h-10 flex items-end px-3">
                  <span className="text-[10px] text-gray-400 uppercase font-sans font-black mb-1.5 tracking-wider">Signature:</span>
                </div>
                <div className="w-48 border-b-2 border-gray-300 h-10 flex items-end px-3">
                  <span className="text-[10px] text-gray-400 uppercase font-sans font-black mr-3 mb-1.5 tracking-wider">Date:</span>
                  <span className="text-xs font-sans font-bold text-gray-900 mb-1.5">
                    {sig.label === 'Prepared By' ? format(new Date(voucher.date), 'dd/MM/yyyy') : '____/____/____'}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="pt-12 border-t-2 border-gray-100 flex justify-between items-center text-xs font-sans text-gray-400 uppercase tracking-[0.4em] font-bold">
            <p>Generated by StarNet Workflow System &bull; Secure Digital Audit</p>
            <p>ID: {voucher.id}</p>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          @page {
            size: A4;
            margin: 0;
          }
          body * {
            visibility: hidden !important;
          }
          .print-voucher, .print-voucher * {
            visibility: visible !important;
          }
          .print-voucher {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 210mm !important;
            height: 297mm !important;
            padding: 0 !important;
            margin: 0 !important;
            border: none !important;
            box-shadow: none !important;
            background: white !important;
          }
        }
      `}} />
    </div>
  );
}
