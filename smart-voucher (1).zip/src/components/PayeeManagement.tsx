import React, { useState, useEffect } from 'react';
import { Payee } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, addDoc, onSnapshot, query, orderBy, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { User, Plus, Trash2, Edit2, Search, X, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ExcelImport from './ExcelImport';

export default function PayeeManagement() {
  const [payees, setPayees] = useState<Payee[]>([]);
  const [search, setSearch] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
    email: ''
  });

  useEffect(() => {
    const q = query(collection(db, 'payees'), orderBy('name', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      })) as Payee[];
      setPayees(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'payees');
    });
    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setError(null);
    try {
      if (editingId) {
        await updateDoc(doc(db, 'payees', editingId), {
          ...formData,
          updatedAt: new Date().toISOString()
        });
        setEditingId(null);
      } else {
        await addDoc(collection(db, 'payees'), {
          ...formData,
          createdAt: new Date().toISOString()
        });
        setIsAdding(false);
      }
      setFormData({ name: '', address: '', phone: '', email: '' });
    } catch (err: any) {
      console.error('Error saving payee:', err);
      setError('Failed to save payee. Please check your permissions.');
      handleFirestoreError(err, editingId ? OperationType.UPDATE : OperationType.CREATE, 'payees');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    try {
      await deleteDoc(doc(db, 'payees', deletingId));
      setDeletingId(null);
    } catch (err: any) {
      console.error('Error deleting payee:', err);
      setError('Failed to delete payee.');
    }
  };

  const handleImport = async (data: any[]) => {
    setIsSaving(true);
    setError(null);
    let count = 0;
    try {
      for (const item of data) {
        if (!item.name) continue;
        await addDoc(collection(db, 'payees'), {
          name: item.name,
          address: item.address || '',
          phone: item.phone || '',
          email: item.email || '',
          createdAt: new Date().toISOString()
        });
        count++;
      }
    } catch (err: any) {
      console.error('Error importing payees:', err);
      setError(`Import failed after ${count} payees. Check permissions.`);
    } finally {
      setIsSaving(false);
    }
  };

  const filteredPayees = payees.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-sans font-bold text-netsuite-blue">Payee Registry</h1>
          <p className="text-[10px] text-gray-500 font-sans uppercase tracking-widest mt-1">Maintain Authorized Payees</p>
        </div>
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 bg-netsuite-blue text-white px-6 py-2 rounded hover:bg-netsuite-blue-dark transition-all font-sans text-sm shadow-sm"
        >
          <Plus size={18} />
          Add Payee
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search payees..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-2 bg-white border border-gray-200 rounded focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-sans text-sm"
            />
          </div>

          <ExcelImport 
            title="Payees"
            template={['name', 'address', 'phone', 'email']}
            onImport={handleImport}
          />
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white rounded border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="px-6 py-3 text-[10px] font-sans uppercase tracking-widest text-gray-400">Name</th>
                  <th className="px-6 py-3 text-[10px] font-sans uppercase tracking-widest text-gray-400">Contact</th>
                  <th className="px-6 py-3 text-[10px] font-sans uppercase tracking-widest text-gray-400 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredPayees.map((payee) => (
                  <tr key={payee.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-6 py-3">
                      <div className="font-bold text-gray-900">{payee.name}</div>
                      <div className="text-xs text-gray-500 font-sans truncate max-w-[200px]">{payee.address}</div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="text-sm text-gray-600">{payee.email}</div>
                      <div className="text-xs text-gray-400 font-sans">{payee.phone}</div>
                    </td>
                    <td className="px-6 py-3 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => {
                            setEditingId(payee.id);
                            setFormData({
                              name: payee.name,
                              address: payee.address || '',
                              phone: payee.phone || '',
                              email: payee.email || ''
                            });
                          }}
                          className="p-2 text-gray-400 hover:text-netsuite-blue hover:bg-netsuite-blue/5 rounded transition-all"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => setDeletingId(payee.id)}
                          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredPayees.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-6 py-12 text-center text-gray-400 font-sans text-sm">
                      No payees found matching your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-24 right-8 bg-red-50 border border-red-200 text-red-600 px-6 py-4 rounded-2xl shadow-xl z-[60] flex items-center gap-3"
          >
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="font-mono text-xs uppercase tracking-wider">{error}</span>
            <button onClick={() => setError(null)} className="ml-4 hover:bg-red-100 p-1 rounded-lg">
              <X size={14} />
            </button>
          </motion.div>
        )}

        {deletingId && (
          <div className="fixed inset-0 bg-netsuite-blue/20 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-8 text-center space-y-6"
            >
              <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto">
                <Trash2 size={32} />
              </div>
              <div>
                <h3 className="text-xl font-serif italic text-gray-900">Delete Payee?</h3>
                <p className="text-sm text-gray-500 mt-2">This action cannot be undone. All records for this payee will remain, but the payee will be removed from the registry.</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setDeletingId(null)}
                  className="flex-1 px-6 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-all font-mono text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDelete}
                  className="flex-1 px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all font-mono text-sm shadow-lg shadow-red-200"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {(isAdding || editingId) && (
          <div className="fixed inset-0 bg-netsuite-blue/20 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="bg-netsuite-blue p-6 text-white flex items-center justify-between">
                <h2 className="text-xl font-serif italic">{editingId ? 'Edit Payee' : 'Add New Payee'}</h2>
                <button onClick={() => { setIsAdding(false); setEditingId(null); setError(null); }} className="hover:bg-white/10 p-2 rounded-lg transition-all">
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-gray-400 mb-1">Payee Name (As on Check)</label>
                    <input
                      required
                      type="text"
                      disabled={isSaving}
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-mono text-sm disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-gray-400 mb-1">Address</label>
                    <textarea
                      disabled={isSaving}
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-mono text-sm h-20 resize-none disabled:opacity-50"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-mono uppercase tracking-widest text-gray-400 mb-1">Phone</label>
                      <input
                        type="tel"
                        disabled={isSaving}
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-mono text-sm disabled:opacity-50"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-mono uppercase tracking-widest text-gray-400 mb-1">Email</label>
                      <input
                        type="email"
                        disabled={isSaving}
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-netsuite-blue/20 focus:border-netsuite-blue transition-all font-mono text-sm disabled:opacity-50"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={() => { setIsAdding(false); setEditingId(null); setError(null); }}
                    className="flex-1 px-6 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-all font-mono text-sm disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 px-6 py-3 bg-netsuite-blue text-white rounded-xl hover:bg-netsuite-blue-dark transition-all font-mono text-sm shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSaving ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Check size={18} />
                    )}
                    {editingId ? 'Update' : 'Save'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
